package com.example.demo2.view.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

public class MusicaRequest {

    @NotBlank(message = "O TITULO NÃO PODE TER CARACTERES EM BRANCO.")
    @NotEmpty(message = "o TITULO NÃO PODE SER VAZIO.")
    private String titulo;

    @NotBlank(message = "O ARTISTA NÃO PODE TER CARACTERES EM BRANCO.")
    @NotEmpty(message = "O ARTISTA NÃO PODE SER VAZIO.")
    private String artista;
    
    @NotBlank(message = "O ALBUM NÃO PODE TER CARACTERES EM BRANCO.")
    @NotEmpty(message = "O ALBUM NÃO PODE SER VAZIO.")
    private String album;
    
    @NotBlank(message = "O GENERO NÃO PODE TER CARACTERES EM BRANCO.")
    @NotEmpty(message = "O GENERO NÃO PODE SER VAZIO.")
    private String genero;

    @Digits(fraction = 0, integer = 4,message = "ANO DE LANÇAMENTO INVÁLIDO. DIGITE UM NÚMERO COM QUATRO DIGITOS.")
    private int anoLancamento;
    
    @NotBlank(message = "O COMPOSITOR NÃO PODE TER CARACTERES EM BRANCO")
    @NotEmpty(message = "O COMPOSITOR NÃO PODE SER VAZIO.")
    private String compositor;

    
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getArtista() {
        return artista;
    }
    public void setArtista(String artista) {
        this.artista = artista;
    }
    public String getAlbum() {
        return album;
    }
    public void setAlbum(String album) {
        this.album = album;
    }
    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public int getAnoLancamento() {
        return anoLancamento;
    }
    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }
    public String getCompositor() {
        return compositor;
    }
    public void setCompositor(String compositor) {
        this.compositor = compositor;
    }

}
